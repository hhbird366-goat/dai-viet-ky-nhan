document.addEventListener("DOMContentLoaded", function () {

  /* ================= BASE PATH ================= */
  const isSub = location.pathname.includes("/pages/");
  const base = isSub ? "../" : "";

  /* ================= HEADER LINKS ================= */
  const homeLink = document.getElementById("homeLink");
  const homeMenu = document.getElementById("homeMenu");
  const authorLink = document.getElementById("authorLink");

  if (homeLink) homeLink.href = base + "index.html";
  if (homeMenu) homeMenu.href = base + "index.html";
  if (authorLink) authorLink.href = base + "pages/credit.html";

  /* ================= DROPDOWN LINKS ================= */
  document.querySelectorAll("[data-page]").forEach(item => {
    item.href = base + "pages/" + item.dataset.page;
  });

  /* ================= DROPDOWN TOGGLE ================= */
  const btn = document.getElementById("dropdownBtn");
  const menu = document.getElementById("dropdownMenu");

  if (btn && menu) {
    btn.addEventListener("click", e => {
      e.stopPropagation();
      menu.classList.toggle("show");
    });

    document.addEventListener("click", () => {
      menu.classList.remove("show");
    });

    menu.style.position = "absolute";
    menu.style.zIndex = 999;
  }

  /* ================= FEATURED CARDS ================= */
  const featuredContainer = document.getElementById("featuredCards");

  if (featuredContainer) {
    const subPages = [
      { title: "Ngô Quyền", link: "pages/sub1.html" },
      { title: "Lý Thường Kiệt", link: "pages/sub2.html" },
      { title: "Nguyễn Trãi", link: "pages/sub3.html" },
      { title: "Trần Hưng Đạo", link: "pages/sub4.html" },
      { title: "Hồ Chí Minh", link: "pages/sub5.html" }
    ];

    const shuffled = subPages.sort(() => Math.random() - 0.5);

    shuffled.slice(0, 4).forEach(sub => {
      const card = document.createElement("a");
      card.className = "card";
      card.href = base + sub.link;
      card.textContent = sub.title;
      featuredContainer.appendChild(card);
    });
  }

  /* =================================================
     SUB PAGE – TOC SCROLL SPY (KHÔNG ẢNH HƯỞNG HEADER)
  ================================================= */

  const tocLinks = document.querySelectorAll(".toc a");
  const sections = document.querySelectorAll(".sub-content h2[id]");

  if (tocLinks.length && sections.length) {

    const observer = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const id = entry.target.id;

            tocLinks.forEach(link => {
              link.classList.toggle(
                "active",
                link.getAttribute("href") === `#${id}`
              );
            });
          }
        });
      },
      {
        root: null,
        rootMargin: "-30% 0px -55% 0px",
        threshold: 0
      }
    );

    sections.forEach(section => observer.observe(section));
  }

});
